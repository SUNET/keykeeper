Shamir Secret Sharing using EEPROM (memory) "smart" cards.


